<?php

/**
 * @see ZendX_JQuery_Exception
 */
// require_once "ZendX/JQuery/Exception.php";

class ZendX_JQuery_Form_Exception extends ZendX_JQuery_Exception
{

}