<?php
return array (
  'PPN_Validate_Honeypot' => __DIR__ . DIRECTORY_SEPARATOR . 'Validate' . DIRECTORY_SEPARATOR . 'Honeypot.php',
  'PPN_View_Helper_FlashMessenger' => __DIR__ . DIRECTORY_SEPARATOR . 'View' . DIRECTORY_SEPARATOR . 'Helper' . DIRECTORY_SEPARATOR . 'FlashMessenger.php',
  'PPN_View_Helper_SpanTag' => __DIR__ . DIRECTORY_SEPARATOR . 'View' . DIRECTORY_SEPARATOR . 'Helper' . DIRECTORY_SEPARATOR . 'SpanTag.php',
  'PPN_View_Helper_DivCloud' => __DIR__ . DIRECTORY_SEPARATOR . 'View' . DIRECTORY_SEPARATOR . 'Helper' . DIRECTORY_SEPARATOR . 'DivCloud.php',
  'PPN_Filter_Slug' => __DIR__ . DIRECTORY_SEPARATOR . 'Filter' . DIRECTORY_SEPARATOR . 'Slug.php',
  'PPN\\Form\\AbstractForm' => __DIR__ . DIRECTORY_SEPARATOR . 'Form' . DIRECTORY_SEPARATOR . 'AbstractForm.php',
  'PPN\\Model\\Resource\\AbstractResource' => __DIR__ . DIRECTORY_SEPARATOR . 'Model' . DIRECTORY_SEPARATOR . 'Resource' . DIRECTORY_SEPARATOR . 'AbstractResource.php',
  'PPN_Model_Resource_Item_Abstract' => __DIR__ . DIRECTORY_SEPARATOR . 'Model' . DIRECTORY_SEPARATOR . 'Resource' . DIRECTORY_SEPARATOR . 'Item' . DIRECTORY_SEPARATOR . 'Abstract.php',
  'PPN\\Model\\AbstractModel' => __DIR__ . DIRECTORY_SEPARATOR . 'Model' . DIRECTORY_SEPARATOR . 'AbstractModel.php',
  'PPN_Exception_NotFound' => __DIR__ . DIRECTORY_SEPARATOR . 'Exception' . DIRECTORY_SEPARATOR . 'NotFound.php',
  'PPN_Exception' => __DIR__ . DIRECTORY_SEPARATOR . 'Exception.php',
  'PPN\\Plugin\\AdminContext' => __DIR__ . DIRECTORY_SEPARATOR . 'Plugin' . DIRECTORY_SEPARATOR . 'AdminContext.php',
);