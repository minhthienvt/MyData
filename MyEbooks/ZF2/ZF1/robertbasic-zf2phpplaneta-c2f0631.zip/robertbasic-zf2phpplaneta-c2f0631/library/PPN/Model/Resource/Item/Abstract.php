<?php

/**
 * Abstract class for one table row
 *
 * @author robert
 */
class PPN_Model_Resource_Item_Abstract extends Zend_Db_Table_Row_Abstract
{
}