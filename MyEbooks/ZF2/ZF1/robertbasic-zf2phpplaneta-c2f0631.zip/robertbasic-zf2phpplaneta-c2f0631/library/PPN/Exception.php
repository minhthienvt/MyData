<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Exception
 *
 * @author robert
 */
class PPN_Exception extends Zend_Exception
{
}