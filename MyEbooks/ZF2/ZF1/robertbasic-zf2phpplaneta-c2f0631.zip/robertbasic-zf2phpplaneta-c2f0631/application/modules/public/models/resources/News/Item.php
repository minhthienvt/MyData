<?php

namespace Planet\Model\Resource\News;

use PPN\Model\Resource\Item\AbstractItem;

/**
 * One row from the news table
 *
 * @author robert
 */
class Item extends AbstractItem
{
}