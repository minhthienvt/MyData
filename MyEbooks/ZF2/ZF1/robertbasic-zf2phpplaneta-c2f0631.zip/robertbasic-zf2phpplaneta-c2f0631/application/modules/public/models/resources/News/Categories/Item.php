<?php

/**
 * One row from the news_categories table
 *
 * @author robert
 */
class Planet_Model_Resource_News_Categories_Item extends PPN_Model_Resource_Item_Abstract
{
}