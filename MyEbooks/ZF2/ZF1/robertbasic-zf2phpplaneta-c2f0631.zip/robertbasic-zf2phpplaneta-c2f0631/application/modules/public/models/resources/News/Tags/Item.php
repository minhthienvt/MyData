<?php

/**
 * One row from the news_sources table
 *
 * @author robert
 */
class Planet_Model_Resource_News_Tags_Item extends PPN_Model_Resource_Item_Abstract
{
}