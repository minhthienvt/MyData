ALTER TABLE `ppn_news` DROP `fk_news_source_id`;
DROP TABLE `ppn_news_sources`;